Synthetic archive preview.
